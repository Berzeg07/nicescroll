$(function() {

    $(".js-nicescroll").niceScroll({
        cursorcolor: "#424242",
        cursorwidth: "10px",
        cursorborder: "0",
        cursorborderradius: "0",
        autohidemode: false,
        cursorminheight: 50,
        horizrailenabled: false,
        railpadding: { top: 5, right: 2, left: 0, bottom: 5 },
    });

});
